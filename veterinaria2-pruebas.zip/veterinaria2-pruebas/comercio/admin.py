from django.contrib import admin
from comercio.models import *
# Register your models here.
admin.site.register(Producto)